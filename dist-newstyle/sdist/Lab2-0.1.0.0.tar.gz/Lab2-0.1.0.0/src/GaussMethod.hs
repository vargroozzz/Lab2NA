module GaussMethod
  ( gaussMethod
  )
where

import           Data.Matrix

gaussMethod matrix = ()

